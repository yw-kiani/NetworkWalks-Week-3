#!/usr/bin/env python3
from Crypto.Util.number import getPrime, bytes_to_long, inverse, GCD
import secrets

try:
    FLAG = open("/flag.txt", "rb").read().strip()
except FileNotFoundError:
    FLAG = b"flag{fake_flag_for_testing}"

NBITS = 512        
n     = 2          
BBITS = 16         
UBITS = 262       

def keygen():
    while True:
        p = getPrime(NBITS // 2)
        q = getPrime(NBITS // 2)
        if not (q < p < 2 * q):
            p, q = max(p, q), min(p, q)
            if not (q < p < 2 * q):
                continue
        N = p * q
        b = secrets.randbits(BBITS) | (1 << (BBITS - 1))
        a = (b * p**n + q**n // 2) // q**n
        psi = (p**n - a) * (q**n - b)
        u = secrets.randbits(UBITS) | (1 << (UBITS - 1))
        if GCD(u, psi) != 1:
            continue
        e = inverse(u, psi)
        phi = (p - 1) * (q - 1)
        if GCD(e, phi) != 1:
            continue
        return N, e, p, q, a, b, u

m = bytes_to_long(FLAG)
while True:
    N, e, p, q, a, b, u = keygen()
    if m < N:
        break
c = pow(m, e, N)

print(f"N = {N}")
print(f"e = {e}")
print(f"c = {c}")
